# Pet Care App

This is a web-based app to manage pet care services like grooming, appointments, medical records, and more.

## Features
- Pet profiles
- Appointment booking
- Grooming services
- Vet services
- In-app payments
- Notifications
